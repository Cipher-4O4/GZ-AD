﻿#include <iostream>
#include <unistd.h>
using namespace std;

struct Book {
  virtual void read() const = 0;
  virtual ~Book() = default;
};

struct SpotlightPage : Book {
  char page[128]{};
  void read() const override { cout << "Miku's spotlight note:\n" << page << '\n'; }
};

struct FanMessagePage : Book {
  char message[128]{};
  void read() const override { cout << "Teto's fan message:\n" << message << '\n'; }
};

struct StageScrapbook {
  SpotlightPage spotlight;
  FanMessagePage fan_messages;
};

StageScrapbook scrapbook;
Book* books[] = {&scrapbook.spotlight, &scrapbook.fan_messages};

void write_spotlight_note() {
  cin.ignore();
  cout << "Miku's spotlight note: " << flush;

  ssize_t length = ::read(STDIN_FILENO, scrapbook.spotlight.page, 0x400);
  if (length >= 0 && length < sizeof(scrapbook.spotlight.page))
    scrapbook.spotlight.page[length] = '\0';

  cout << "Spotlight note saved\n";
}

void leave_fan_message() {
  cin.ignore();
  cout << "Teto's fan message: ";
  cin.getline(scrapbook.fan_messages.message, sizeof(scrapbook.fan_messages.message));
  cout << "Fan message saved\n";
}

void read_scrapbook_page() {
  unsigned index;
  cout << "0. Miku's spotlight notes\n1. Teto's fan messages\nIndex: ";
  if (!(cin >> index) || index >= 2) {
    cout << "Invalid index\n";
    return;
  }
  books[index]->read();
}

int main() {
  while (true) {
    cout << "(C)PPPP!\n"
            "1. Write Miku's spotlight note\n"
            "2. Leave Teto a fan message\n"
            "3. Read a scrapbook page\n"
            "4. Exit\n> ";
    unsigned choice;
    if (!(cin >> choice)) return 0;
    switch (choice) {
      case 1: write_spotlight_note(); break;
      case 2: leave_fan_message(); break;
      case 3: read_scrapbook_page(); break;
      case 4: return 0;
      default: cout << "Invalid choice\n";
    }
  }
}
