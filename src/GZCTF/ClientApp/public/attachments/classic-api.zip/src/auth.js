const { createHash, createHmac } = require("node:crypto");

const { equalString } = require("./crypto-utils");
const { HttpError } = require("./errors");
const state = require("./state");
const { isObject } = require("./validation");

const { users } = state;

function hasUser(username) {
  return Object.prototype.hasOwnProperty.call(users, username);
}

function createPasswordHash(password) {
  return createHash("sha256")
    .update(`${password}:${state.getSecretKey()}:password`)
    .digest("hex");
}

function createToken(username) {
  const payload = Buffer.from(
    JSON.stringify({ username, issuedAt: Date.now() })
  ).toString("base64url");
  const signature = createHmac("sha256", state.getSecretKey())
    .update(payload)
    .digest("base64url");

  return `${payload}.${signature}`;
}

function verifyToken(token) {
  if (typeof token !== "string") {
    return null;
  }

  const [payload, signature] = token.split(".");
  if (!payload || !signature) {
    return null;
  }

  const expected = createHmac("sha256", state.getSecretKey())
    .update(payload)
    .digest("base64url");

  if (!equalString(signature, expected)) {
    return null;
  }

  try {
    const session = JSON.parse(Buffer.from(payload, "base64url").toString());
    if (!hasUser(session.username)) {
      return null;
    }

    return session.username;
  } catch {
    return null;
  }
}

function requireAuth(req, res, next) {
  const authorization = req.get("authorization") || "";
  const [scheme, token] = authorization.split(" ");

  if (scheme !== "Bearer") {
    next(new HttpError(401, "Missing bearer token"));
    return;
  }

  const username = verifyToken(token);
  if (!username) {
    next(new HttpError(401, "Invalid bearer token"));
    return;
  }

  req.username = username;
  next();
}

function getProfile(username) {
  if (!isObject(users[username].profile)) {
    users[username].profile = {};
  }

  return users[username].profile;
}

module.exports = {
  createPasswordHash,
  createToken,
  getProfile,
  hasUser,
  requireAuth,
};
