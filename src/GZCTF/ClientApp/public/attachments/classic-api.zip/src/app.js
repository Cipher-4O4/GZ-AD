const express = require("express");

const { HttpError } = require("./errors");
const { adminRouter } = require("./routes/admin");
const { authRouter } = require("./routes/auth");
const { backupRouter } = require("./routes/backup");
const { notesRouter } = require("./routes/notes");
const { profileRouter } = require("./routes/profile");
const { signingRouter } = require("./routes/signing");

const app = express();

app.use(express.json({ limit: "64kb" }));

app.get("/", (req, res) => {
  res.json({
    message: "Hello, World!",
    success: true,
    service: "classic-api",
    routes: [
      "/register",
      "/login",
      "/profile",
      "/notes",
      "/sign",
      "/verify",
      "/admin",
      "/backup/import",
      "/health",
    ],
  });
});

// NOTICE: DON'T MODIFY OR REMOVE THIS
app.get("/health", (req, res) => {
  res.json({ success: true, status: "ok" });
});

app.use(authRouter);
app.use(backupRouter);
app.use(profileRouter);
app.use(notesRouter);
app.use(signingRouter);
app.use(adminRouter);

app.use((req, res) => {
  res.status(404).send("Not found");
});

app.use((error, req, res, next) => {
  if (error instanceof SyntaxError && "body" in error) {
    res.status(400).json({ success: false, error: "Invalid JSON body" });
    return;
  }

  if (error instanceof HttpError) {
    res.status(error.status).json({ success: false, error: error.message });
    return;
  }

  res.status(500).json({ success: false, error: "Internal server error" });
});

module.exports = { app };
