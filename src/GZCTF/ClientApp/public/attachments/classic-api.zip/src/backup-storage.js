const { rmSync } = require("node:fs");
const { join } = require("node:path");

const configuredNamespace = process.env.BACKUP_NAMESPACE || process.env.TEAM_ID || "default";
const backupNamespace = configuredNamespace.replace(/[^a-zA-Z0-9_-]/g, "_").slice(0, 64) || "default";
const backupBase = join("/tmp/kos0ng-backups", backupNamespace);

function restoreRoot(username) {
  return join(backupBase, username);
}

function clearBackupStorage() {
  rmSync(backupBase, { force: true, recursive: true });
}

module.exports = {
  clearBackupStorage,
  restoreRoot,
};
