const { calculate } = require("./crypto-utils");
const { getSecretKey } = require("./state");

function signContent(content, nonce = "") {
  let secret = getSecretKey();

  if (nonce) {
    secret = calculate(nonce, secret);
  }

  return calculate(content, secret);
}

module.exports = {
  signContent,
};
