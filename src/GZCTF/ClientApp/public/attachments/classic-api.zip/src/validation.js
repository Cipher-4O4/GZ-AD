const { HttpError } = require("./errors");

function assertText(value, field, min = 1, max = 256) {
  if (typeof value !== "string") {
    throw new HttpError(400, `${field} must be a string`);
  }

  const trimmed = value.trim();
  if (trimmed.length < min || trimmed.length > max) {
    throw new HttpError(400, `${field} length is invalid`);
  }

  return trimmed;
}

function isObject(value) {
  return value !== null && typeof value === "object" && !Array.isArray(value);
}

function mergeValues(target, source) {
  for (const key of Object.keys(source)) {
    if (isObject(source[key]) && isObject(target[key])) {
      mergeValues(target[key], source[key]);
    } else {
      target[key] = source[key];
    }
  }

  return target;
}

module.exports = {
  assertText,
  isObject,
  mergeValues,
};
