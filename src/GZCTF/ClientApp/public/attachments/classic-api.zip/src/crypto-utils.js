const { createHash, timingSafeEqual } = require("node:crypto");

function calculate(data, secret) {
  if (typeof data !== "string") {
    throw new Error("Data must be a string");
  }

  return createHash("sha256").update(data + secret).digest("hex");
}

function equalString(left, right) {
  if (typeof left !== "string" || typeof right !== "string") {
    return false;
  }

  const leftBuffer = Buffer.from(left);
  const rightBuffer = Buffer.from(right);

  if (leftBuffer.length !== rightBuffer.length) {
    return false;
  }

  return timingSafeEqual(leftBuffer, rightBuffer);
}

module.exports = {
  calculate,
  equalString,
};
