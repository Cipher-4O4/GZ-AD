const { randomUUID } = require("node:crypto");
const { DatabaseSync } = require("node:sqlite");
const { dirname } = require("node:path");
const { mkdirSync } = require("node:fs");

const { clearBackupStorage } = require("./backup-storage");

const DATABASE_FILE = process.env.DB_FILE || "/tmp/db.sqlite";
const resetIntervalSetting = process.env.DB_RESET_INTERVAL_MS;
const RESET_INTERVAL_MS = Number(
  resetIntervalSetting === undefined ? 15 * 60 * 1000 : resetIntervalSetting,
);

const databaseDirectory = dirname(DATABASE_FILE);
if (databaseDirectory !== ".") {
  mkdirSync(databaseDirectory, { recursive: true });
}

function openDatabase() {
  const database = new DatabaseSync(DATABASE_FILE);
  database.exec(`
    PRAGMA busy_timeout = 5000;

    CREATE TABLE IF NOT EXISTS metadata (
      key TEXT PRIMARY KEY,
      value TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS users (
      username TEXT PRIMARY KEY,
      data TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS notes (
      id TEXT PRIMARY KEY,
      data TEXT NOT NULL
    );
  `);
  return database;
}

let database = openDatabase();
let secretKey;
const users = {};
const notes = {};

function loadState() {
  const metadata = database
    .prepare("SELECT value FROM metadata WHERE key = ?")
    .get("secretKey");
  secretKey = metadata?.value || randomUUID();

  for (const key of Object.keys(users)) {
    delete users[key];
  }
  for (const key of Object.keys(notes)) {
    delete notes[key];
  }

  for (const row of database
    .prepare("SELECT username, data FROM users")
    .all()) {
    try {
      users[row.username] = JSON.parse(row.data);
    } catch {}
  }

  for (const row of database.prepare("SELECT id, data FROM notes").all()) {
    try {
      notes[row.id] = JSON.parse(row.data);
    } catch {}
  }
}

function reloadState() {
  database.close();
  database = openDatabase();
  loadState();
}

function getSecretKey() {
  return secretKey;
}

function saveState() {
  database.exec("BEGIN IMMEDIATE");

  try {
    database
      .prepare(
        "INSERT INTO metadata (key, value) VALUES (?, ?) " +
          "ON CONFLICT(key) DO UPDATE SET value = excluded.value",
      )
      .run("secretKey", secretKey);

    database.prepare("DELETE FROM users").run();
    const insertUser = database.prepare(
      "INSERT INTO users (username, data) VALUES (?, ?)",
    );
    for (const [username, user] of Object.entries(users)) {
      insertUser.run(username, JSON.stringify(user));
    }

    database.prepare("DELETE FROM notes").run();
    const insertNote = database.prepare(
      "INSERT INTO notes (id, data) VALUES (?, ?)",
    );
    for (const [id, note] of Object.entries(notes)) {
      insertNote.run(id, JSON.stringify(note));
    }

    database.exec("COMMIT");
  } catch (error) {
    database.exec("ROLLBACK");
    throw error;
  }
}

// NOTICE: DON'T MODIFY OR REMOVE THIS
function clearDatabase() {
  database.exec("BEGIN IMMEDIATE");

  try {
    database.exec(
      "DELETE FROM metadata; DELETE FROM users; DELETE FROM notes;",
    );
    for (const key of Object.keys(users)) {
      delete users[key];
    }
    for (const key of Object.keys(notes)) {
      delete notes[key];
    }
    database.exec("COMMIT");
  } catch (error) {
    database.exec("ROLLBACK");
    throw error;
  }
}

loadState();
saveState();

// NOTICE: DON'T MODIFY OR REMOVE THIS
if (Number.isFinite(RESET_INTERVAL_MS) && RESET_INTERVAL_MS > 0) {
  const resetTimer = setInterval(() => {
    try {
      clearDatabase();
      clearBackupStorage();
    } catch (error) {
      console.error("Failed to clear scheduled state:", error);
    }
  }, RESET_INTERVAL_MS);

  resetTimer.unref();
}

module.exports = {
  getSecretKey,
  notes,
  reloadState,
  saveState,
  users,
};
