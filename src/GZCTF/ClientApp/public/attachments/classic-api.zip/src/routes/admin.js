const { Router } = require("express");
const serialize = require("node-serialize");

const { getProfile, requireAuth } = require("../auth");
const { calculate } = require("../crypto-utils");
const { getSecretKey } = require("../state");

const adminRouter = Router();

adminRouter.get("/admin", requireAuth, (req, res) => {
  const profile = getProfile(req.username);

  if (!profile.isAdmin) {
    res.status(403).send("Forbidden");
    return;
  }

  try {
    let content = "hello";
    let secret = getSecretKey();
    let hash = calculate(content, secret);

    if (!req.query.hash || !req.query.content) {
      res.json({
        message: "Missing parameters",
        example: { content, hash },
      });
      return;
    }

    content = req.query.content;
    hash = req.query.hash;
    const nonce = req.query.nonce;
    const isSerialize = req.query.serialize === "true";

    if (nonce) {
      secret = calculate(nonce, secret);
    }

    const hashed = calculate(content, secret);
    if (hashed !== hash) {
      res.status(401).send("Forbidden");
      return;
    }

    if (isSerialize) {
      const serialized = serialize.unserialize(content);
      if (serialized) {
        content = serialized;
      }
    }

    res.json({
      message: "Welcome, Admin",
      success: true,
      content,
    });
  } catch (error) {
    res.json({
      message: "Error",
      success: false,
      error: error.message,
    });
  }
});

module.exports = { adminRouter };
