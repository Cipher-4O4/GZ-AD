const { randomUUID } = require("node:crypto");
const { Router } = require("express");

const { requireAuth } = require("../auth");
const { HttpError } = require("../errors");
const { notes, saveState } = require("../state");

const notesRouter = Router();

function getOwnedNote(id, username) {
  const note = notes[id];

  if (!note || note.owner !== username) {
    throw new HttpError(404, "Note not found");
  }

  return note;
}

notesRouter.get("/notes", requireAuth, (req, res) => {
  const ownNotes = Object.values(notes)
    .filter((note) => note.owner === req.username)
    .map((note) => ({
      id: note.id,
      createdAt: note.createdAt,
      size: note.content.length,
    }));

  res.json({ success: true, notes: ownNotes });
});

notesRouter.post("/notes", requireAuth, (req, res, next) => {
  try {
    if (typeof req.body.content !== "string" || req.body.content.length > 4096) {
      throw new HttpError(400, "content must be a string up to 4096 bytes");
    }

    const id = randomUUID();
    notes[id] = {
      id,
      owner: req.username,
      content: req.body.content,
      createdAt: new Date().toISOString(),
    };

    saveState();

    res.status(201).json({ success: true, id });
  } catch (error) {
    next(error);
  }
});

notesRouter.get("/notes/:id", requireAuth, (req, res, next) => {
  try {
    const note = getOwnedNote(req.params.id, req.username);

    res.json({
      success: true,
      id: note.id,
      content: note.content,
      createdAt: note.createdAt,
    });
  } catch (error) {
    next(error);
  }
});

module.exports = {
  getOwnedNote,
  notesRouter,
};
