const AdmZip = require("adm-zip");
const { Router } = require("express");
const { dirname, join } = require("node:path");
const {
  mkdirSync,
  readFileSync,
  symlinkSync,
  unlinkSync,
  writeFileSync,
} = require("node:fs");

const { requireAuth } = require("../auth");
const { restoreRoot } = require("../backup-storage");
const { HttpError } = require("../errors");
const { reloadState } = require("../state");

const backupRouter = Router();

function isSymbolicLink(entry) {
  return ((entry.attr >>> 16) & 0xf000) === 0xa000;
}

backupRouter.get("/backup/file", requireAuth, (req, res, next) => {
  try {
    const name = req.query.name;
    if (
      typeof name !== "string" ||
      name.length === 0 ||
      name !== name.split("/").pop()
    ) {
      throw new HttpError(400, "name must be a file name");
    }

    const file = join(restoreRoot(req.username), name);
    let content;
    try {
      content = readFileSync(file, "utf8");
    } catch (error) {
      if (error.code === "ENOENT") {
        throw new HttpError(404, "Backup file not found");
      }
      throw error;
    }

    unlinkSync(file);
    res.type("text/plain").send(content);
  } catch (error) {
    next(error);
  }
});

backupRouter.post("/backup/import", requireAuth, (req, res, next) => {
  try {
    if (
      typeof req.body.archive !== "string" ||
      req.body.archive.length > 64 * 1024
    ) {
      throw new HttpError(400, "archive must be a base64 ZIP up to 64KB");
    }

    const archive = new AdmZip(Buffer.from(req.body.archive, "base64"));
    const entries = archive.getEntries();
    if (entries.length === 0) {
      throw new HttpError(400, "archive is empty");
    }

    const root = restoreRoot(req.username);
    mkdirSync(root, { recursive: true });

    for (const entry of entries) {
      const destination = join(root, entry.entryName);

      if (entry.isDirectory) {
        mkdirSync(destination, { recursive: true });
        continue;
      }

      mkdirSync(dirname(destination), { recursive: true });
      if (isSymbolicLink(entry)) {
        symlinkSync(entry.getData().toString("utf8"), destination);
      } else {
        writeFileSync(destination, entry.getData());
      }
    }

    reloadState();

    res.json({
      success: true,
      importedEntries: entries.length,
    });
  } catch (error) {
    next(error);
  }
});

module.exports = { backupRouter };
