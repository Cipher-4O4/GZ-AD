const { Router } = require("express");

const { getProfile, requireAuth } = require("../auth");
const { HttpError } = require("../errors");
const { saveState } = require("../state");
const { isObject, mergeValues } = require("../validation");

const profileRouter = Router();

profileRouter.get("/profile", requireAuth, (req, res) => {
  res.json({
    success: true,
    username: req.username,
    profile: getProfile(req.username),
  });
});

profileRouter.patch("/profile", requireAuth, (req, res, next) => {
  try {
    if (!isObject(req.body.profile)) {
      throw new HttpError(400, "profile must be an object");
    }

    if (Object.prototype.hasOwnProperty.call(req.body.profile, "isAdmin")) {
      throw new HttpError(400, "isAdmin cannot be changed through the profile");
    }

    const profile = getProfile(req.username);
    mergeValues(profile, req.body.profile);
    saveState();

    res.json({
      success: true,
      username: req.username,
      profile,
    });
  } catch (error) {
    next(error);
  }
});

module.exports = { profileRouter };
