const { Router } = require("express");

const { requireAuth } = require("../auth");
const { equalString } = require("../crypto-utils");
const { HttpError } = require("../errors");
const { getOwnedNote } = require("./notes");
const { signContent } = require("../signing");

const signingRouter = Router();

signingRouter.get("/sign", requireAuth, (req, res, next) => {
  try {
    const id = req.query.id;
    const nonce = req.query.nonce || "";
    let content = req.query.content;

    if (id) {
      content = getOwnedNote(id, req.username).content;
    }

    if (typeof content !== "string") {
      throw new HttpError(400, "Missing content or note id");
    }

    res.json({
      success: true,
      content,
      nonce,
      hash: signContent(content, nonce),
    });
  } catch (error) {
    next(error);
  }
});

// NOTICE: DON'T MODIFY OR REMOVE THIS
signingRouter.get("/verify", (req, res, next) => {
  try {
    const content = req.query.content;
    const hash = req.query.hash;
    const nonce = req.query.nonce || "";

    if (typeof content !== "string" || typeof hash !== "string") {
      throw new HttpError(400, "Missing content or hash");
    }

    const expected = signContent(content, nonce);

    res.json({
      success: true,
      valid: equalString(hash, expected),
    });
  } catch (error) {
    next(error);
  }
});

module.exports = { signingRouter };
