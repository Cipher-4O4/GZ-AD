const { Router } = require("express");

const {
  createPasswordHash,
  createToken,
  hasUser,
} = require("../auth");
const { equalString } = require("../crypto-utils");
const { HttpError } = require("../errors");
const { saveState, users } = require("../state");
const { assertText } = require("../validation");

const authRouter = Router();

authRouter.post("/register", (req, res, next) => {
  try {
    const username = assertText(req.body.username, "username", 3, 32);
    const password = assertText(req.body.password, "password", 6, 128);

    if (!/^[a-zA-Z0-9_]+$/.test(username)) {
      throw new HttpError(400, "username contains invalid characters");
    }

    if (hasUser(username)) {
      throw new HttpError(409, "User already exists");
    }

    users[username] = {
      username,
      passwordHash: createPasswordHash(password),
      profile: {
        displayName: username,
        theme: "light",
      },
      createdAt: new Date().toISOString(),
    };

    saveState();

    res.status(201).json({ success: true, username });
  } catch (error) {
    next(error);
  }
});

authRouter.post("/login", (req, res, next) => {
  try {
    const username = assertText(req.body.username, "username", 3, 32);
    const password = assertText(req.body.password, "password", 6, 128);

    if (!hasUser(username)) {
      throw new HttpError(401, "Invalid username or password");
    }

    const passwordHash = createPasswordHash(password);
    if (!equalString(users[username].passwordHash, passwordHash)) {
      throw new HttpError(401, "Invalid username or password");
    }

    res.json({
      success: true,
      token: createToken(username),
    });
  } catch (error) {
    next(error);
  }
});

module.exports = { authRouter };
