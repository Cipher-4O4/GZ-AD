const { app } = require("./src/app");

const HOST = process.env.HOST || "0.0.0.0";
const PORT = Number(process.env.PORT || 1337);

app.listen(PORT, HOST, () => {
  console.log(`Listening on http://${HOST}:${PORT}`);
});
