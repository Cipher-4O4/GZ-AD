import re
import time
from contextlib import closing

import accounts

# ORDER BY fragments are picked by key; the request value only selects one.
_SORTS = {
    "new": "id DESC",
    "old": "id ASC",
    "top": "votes DESC, id DESC",
}

_RGB_RE = re.compile(r"rgb\(\s*\d{1,3}\s*,\s*\d{1,3}\s*,\s*\d{1,3}\s*\)|#[0-9A-Fa-f]{6}")

def valid_rgb(value):
    return bool(_RGB_RE.fullmatch((value or "").strip()))

def init_db():
    with closing(accounts.get_db()) as conn:
        conn.execute("""CREATE TABLE IF NOT EXISTS community (
            id         INTEGER PRIMARY KEY AUTOINCREMENT,
            username   TEXT    NOT NULL,
            rgb        TEXT    NOT NULL,
            label      TEXT    NOT NULL DEFAULT '',
            votes      INTEGER NOT NULL DEFAULT 0,
            created_at INTEGER NOT NULL
        )""")
        conn.commit()
        if conn.execute("SELECT COUNT(*) AS n FROM community").fetchone()["n"] == 0:
            conn.execute(
                "INSERT INTO community (username, rgb, label, votes, created_at) "
                "VALUES (?, ?, ?, ?, ?)",
                ("curator", "rgb(255, 107, 107)", "warm start", 3, int(time.time())),
            )
            conn.commit()

def board(sort="new", limit=20):
    order = _SORTS.get(sort, _SORTS["new"])
    with closing(accounts.get_db()) as conn:
        return conn.execute(
            f"SELECT id, username, rgb, label, votes FROM community ORDER BY {order} LIMIT ?",
            (limit,),
        ).fetchall()

def submit(username, rgb, label):
    with closing(accounts.get_db()) as conn:
        conn.execute(
            "INSERT INTO community (username, rgb, label, votes, created_at) "
            "VALUES (?, ?, ?, 0, ?)",
            (username, rgb, label[:60], int(time.time())),
        )
        conn.commit()

def vote(palette_id):
    """Parameterised on purpose - the raw id never reaches the SQL text."""
    try:
        pid = int(palette_id)
    except (TypeError, ValueError):
        return False
    with closing(accounts.get_db()) as conn:
        cur = conn.execute("UPDATE community SET votes = votes + 1 WHERE id = ?", (pid,))
        conn.commit()
        return cur.rowcount > 0
