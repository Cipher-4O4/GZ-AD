import importlib
import io
import json
import os
import pickle
import re

import config

EXPORT_DIR = os.environ.get("EXPORT_DIR", "/tmp/exports")
STEM_RE = re.compile(r"[A-Za-z0-9_-]{1,32}")

class PaletteUnpickler(pickle.Unpickler):

    def find_class(self, module, name):
        if module.split(".")[0] not in config.PICKLE_SAFE_ROOTS:
            raise pickle.UnpicklingError("bundle may not refer to %s.%s" % (module, name))
        if name.startswith("__"):
            raise pickle.UnpicklingError("bundle may not refer to %s.%s" % (module, name))
        obj = importlib.import_module(module)
        for part in name.split("."):
            obj = getattr(obj, part)
        if not callable(obj):
            raise pickle.UnpicklingError("bundle may not refer to %s.%s" % (module, name))
        return obj

def load_bundle(raw):
    return PaletteUnpickler(io.BytesIO(raw)).load()

def ensure_dir():
    os.makedirs(EXPORT_DIR, exist_ok=True)

def as_dict(preset):
    return {
        "title": preset.title,
        "bg": preset.bg,
        "fg": preset.fg,
        "accent": preset.accent,
        "badge": preset.badge,
        "dark": preset.dark,
        "styles": {
            "radius": preset.styles.radius,
            "shadow": preset.styles.shadow,
            "font": preset.styles.font,
        },
    }

def export(name, preset):
    stem = (name or "").strip()
    if not STEM_RE.fullmatch(stem):
        return None, "Name must be 1-32 letters, digits, _ or -"
    ensure_dir()
    path = os.path.join(EXPORT_DIR, stem + ".json")
    with open(path, "w") as f:
        json.dump(as_dict(preset), f, indent=2)
    return stem + ".json", None

def resolve(filename):
    try:
        root = os.path.realpath(EXPORT_DIR)
        path = os.path.realpath(os.path.join(root, filename))
        if os.path.commonpath([path, root]) != root:
            return None
    except (OSError, ValueError):
        return None
    return path

def load(filename):
    path = resolve(filename)
    if path is None:
        return None, "that name points outside the export directory"
    if not os.path.isfile(path):
        return None, "no such export"
    try:
        with open(path) as f:
            return json.load(f), None
    except (OSError, ValueError):
        return None, "that export is not readable JSON"

def save_upload(filename, raw):
    stem = os.path.splitext(os.path.basename(filename or ""))[0]
    if not STEM_RE.fullmatch(stem):
        return None, "Filename must be 1-32 letters, digits, _ or -"
    ext = os.path.splitext(os.path.basename(filename or ""))[1].lower()
    if isinstance(raw, str):
        raw = raw.encode("utf-8", "surrogateescape")
    if ext == ".pkl":
        try:
            data = load_bundle(raw)
        except Exception:
            return None, "Bundle is not a readable palette object"
    else:
        try:
            data = json.loads(raw.decode("utf-8", "replace"))
        except ValueError:
            return None, "Upload is not valid JSON"
    ensure_dir()
    with open(os.path.join(EXPORT_DIR, stem + ".json"), "w") as f:
        json.dump(data, f, indent=2, default=str)
    return stem + ".json", None