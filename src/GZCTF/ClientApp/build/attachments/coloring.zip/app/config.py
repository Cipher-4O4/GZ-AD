import os

UPLOADS_DIR = '/app/uploads'
DB_PATH = os.environ.get("DB_PATH", "/tmp/coloring.db")

FILE_TTL = 2

BLACKLIST = [
    'eval', 'exec', 'compile', 'open', 'getattr', 'os',
    'globals', 'vars', 'builtins', 'bytes', 'listdir', 'spawn',
]

ALLOWED_STATEMENT_CALLS = frozenset({'breakpoint'})

RUN_WRAPPER = """
import sys, os
from parse import rgb_parse
print(rgb_parse(main()))"""

MIN_PASSWORD_LEN = 6

PATCH_FIELDS = frozenset({"bg", "fg", "accent", "badge", "title", "dark", "styles"})
MAX_PATCH_KEYS = 16
MAX_OPTION_LEN = 64

PICKLE_SAFE_ROOTS = frozenset({"palette_io", "presets"})

MAINTENANCE_INTERVAL = 900
ACCOUNT_TTL = 900
EXPORT_TTL = 900