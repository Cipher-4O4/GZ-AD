import json
import os
import secrets
from random import randint

from flask import (Flask, abort, flash, redirect, render_template, request, send_from_directory, session, url_for)

import accounts
import community
import config
import jail
import palette_io
import presets as palette
import sharing

app = Flask(__name__)
app.secret_key = os.environ.get("SECRET_KEY") or secrets.token_hex(32)
app.config.update(
    SESSION_COOKIE_HTTPONLY=True,
    SESSION_COOKIE_SAMESITE='Lax',
)

def random_rgb():
    return f"rgb({randint(0, 256)}, {randint(0, 256)}, {randint(0, 256)})"

# Routes

@app.route('/health')
def health():
    return "ok\n", 200, {"Content-Type": "text/plain"}

@app.route('/')
def index():
    if session.get('uid'):
        return redirect(url_for('dashboard'))
    return redirect(url_for('login'))

@app.route('/register', methods=["GET", "POST"])
def register():
    if session.get('uid'):
        return redirect(url_for('dashboard'))

    if request.method == "POST":
        username = (request.form.get("username") or "").strip()
        password = request.form.get("password") or ""
        confirm = request.form.get("confirm") or ""

        if not accounts.USERNAME_RE.fullmatch(username):
            flash("Username must be 3-32 characters: letters, digits, _ or -", "err")
        elif len(password) < config.MIN_PASSWORD_LEN:
            flash(f"Password must be at least {config.MIN_PASSWORD_LEN} characters", "err")
        elif password != confirm:
            flash("Passwords do not match", "err")
        elif not accounts.create_user(username, password):
            flash("That username is already taken", "err")
        else:
            flash("Account created - you can sign in now", "ok")
            return redirect(url_for('login'))

    return render_template("register.html")

@app.route('/login', methods=["GET", "POST"])
def login():
    if session.get('uid'):
        return redirect(url_for('dashboard'))

    if request.method == "POST":
        username = (request.form.get("username") or "").strip()
        password = request.form.get("password") or ""

        creds = accounts.authenticate(username, password)
        if creds:
            uid, name = creds
            session.clear()
            session['uid'] = uid
            session['user'] = name
            session['preset'] = accounts.load_profile(uid)[0]
            return redirect(accounts.safe_next(request.form.get("next")) or url_for('dashboard'))

        flash("Invalid username or password", "err")

    return render_template("login.html", next=accounts.safe_next(request.args.get("next")) or "")

@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('login'))

@app.route('/presets', methods=["GET", "POST"])
@accounts.login_required
def presets():
    active, options = accounts.load_profile(session['uid'])

    if request.method == "POST":
        chosen = request.form.get("preset", "warm")
        if chosen not in palette.PRESETS:
            chosen = "warm"

        raw = (request.form.get("options") or "").strip()
        if raw:
            try:
                patch = json.loads(raw)
            except ValueError:
                flash("Advanced options must be valid JSON", "err")
                return redirect(url_for('presets'))
            if not palette.patch_ok(patch):
                flash("Advanced options hold a field that cannot be set", "err")
                return redirect(url_for('presets'))
            palette.merge(palette.PRESETS[chosen], patch)

        session['preset'] = chosen
        accounts.save_profile(session['uid'], chosen, raw)
        flash("Preset updated", "ok")
        return redirect(url_for('presets'))

    return render_template("presets.html", presets=palette.PRESETS, active=active, options=options, active_css=palette.active(active).to_css())

@app.route('/dashboard', methods=["GET", "POST"])
@accounts.login_required
def dashboard():
    rgb = random_rgb()
    code = ""

    if request.method == "POST":
        code = request.form["code"]
        rgb = jail.rgb_from_output(jail.xec(code)) or random_rgb()

    preset = palette.active(session.get('preset', 'warm'))
    return render_template("index.html", rgb=rgb, code=code, preset=preset, theme_css=preset.to_css())

@app.route('/uploads/<path:filename>')
@app.route('/tmp/uploads/<path:filename>')
def uploaded(filename):
    return send_from_directory(config.UPLOADS_DIR, filename)

# Sharing and Gallery

@app.route('/gallery')
def gallery():
    return render_template("gallery.html", shares=sharing.gallery())

@app.route('/share', methods=["POST"])
@accounts.login_required
def share():
    note = (request.form.get("note") or "").strip()
    rgb = request.form.get("rgb") or random_rgb()
    sharing.publish(session['user'], rgb, note)
    flash("Shared to the gallery", "ok")
    return redirect(url_for('gallery'))

@app.route('/share/<path:token>')
def shared(token):
    decoded = sharing.read_token(token)
    if decoded is None:
        abort(404)
    username, rgb = decoded
    return render_template("share.html", username=username, rgb=rgb, token=sharing.make_token(username, rgb))

# Palette file management

@app.route('/palette', methods=["GET", "POST"])
@accounts.login_required
def palette_files():
    preview, filename, error = None, None, None
    active = palette.active(session.get('preset', 'warm'))

    if request.method == "POST":
        action = request.form.get("action", "export")
        if action == "export":
            filename, error = palette_io.export(request.form.get("name"), active)
        else:
            upload = request.files.get("palette")
            if upload is None or not upload.filename:
                error = "Choose a JSON file to upload"
            else:
                filename, error = palette_io.save_upload(
                    upload.filename, upload.stream.read())

    wanted = request.args.get("file")
    if wanted:
        preview, error = palette_io.load(wanted)
        filename = wanted

    return render_template("palette.html", exports=sorted(os.listdir(palette_io.EXPORT_DIR)) if os.path.isdir(palette_io.EXPORT_DIR) else [], filename=filename, preview=preview, error=error)

# Community palette board

@app.route('/community')
def community_board():
    sort = request.args.get("sort", "new")
    return render_template("community.html", palettes=community.board(sort), sort=sort)

@app.route('/community/submit', methods=["POST"])
@accounts.login_required
def community_submit():
    rgb = (request.form.get("rgb") or "").strip()
    if not community.valid_rgb(rgb):
        rgb = random_rgb()
    label = (request.form.get("label") or "").strip()
    community.submit(session['user'], rgb, label)
    flash("Added to the community board", "ok")
    return redirect(url_for('community_board'))

@app.route('/community/vote', methods=["POST"])
def community_vote():
    if not community.vote(request.form.get("id")):
        flash("No such palette", "err")
    return redirect(url_for('community_board'))

accounts.init_db()
sharing.init_db()
community.init_db()

if __name__ == "__main__":
    app.run(host='0.0.0.0', port=int(os.environ.get("PORT", 8080)), threaded=True)