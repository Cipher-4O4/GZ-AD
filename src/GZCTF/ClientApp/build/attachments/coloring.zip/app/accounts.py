import os
import re
import sqlite3
import time
from contextlib import closing
from functools import wraps

from flask import redirect, request, session, url_for
from werkzeug.security import generate_password_hash, check_password_hash

import config

USERNAME_RE = re.compile(r"[A-Za-z0-9_-]{3,32}")

def get_db():
    conn = sqlite3.connect(config.DB_PATH, timeout=5)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    os.makedirs(os.path.dirname(config.DB_PATH) or "/tmp", exist_ok=True)
    with closing(get_db()) as conn:
        conn.execute("""CREATE TABLE IF NOT EXISTS users (
            id            INTEGER PRIMARY KEY AUTOINCREMENT,
            username      TEXT    NOT NULL UNIQUE,
            password_hash TEXT    NOT NULL,
            created_at    INTEGER NOT NULL
        )""")
        conn.execute("""CREATE TABLE IF NOT EXISTS profiles (
            user_id  INTEGER PRIMARY KEY,
            preset   TEXT    NOT NULL,
            options  TEXT    NOT NULL DEFAULT ''
        )""")
        conn.commit()

def create_user(username, password):
    try:
        with closing(get_db()) as conn:
            conn.execute(
                "INSERT INTO users (username, password_hash, created_at) VALUES (?, ?, ?)",
                (username, generate_password_hash(password), int(time.time())),
            )
            conn.commit()
        return True
    except sqlite3.IntegrityError:
        return False

def authenticate(username, password):
    with closing(get_db()) as conn:
        row = conn.execute(
            "SELECT id, username, password_hash FROM users WHERE username = ?",
            (username,),
        ).fetchone()
    if row and check_password_hash(row["password_hash"], password):
        return row["id"], row["username"]
    return None

def save_profile(user_id, preset, options):
    with closing(get_db()) as conn:
        conn.execute(
            "INSERT INTO profiles (user_id, preset, options) VALUES (?, ?, ?) "
            "ON CONFLICT(user_id) DO UPDATE SET preset = excluded.preset, options = excluded.options",
            (user_id, preset, options),
        )
        conn.commit()

def load_profile(user_id):
    with closing(get_db()) as conn:
        row = conn.execute(
            "SELECT preset, options FROM profiles WHERE user_id = ?", (user_id,)
        ).fetchone()
    return (row["preset"], row["options"]) if row else ("warm", "")

def login_required(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        if not session.get('uid'):
            return redirect(url_for('login', next=request.path))
        return view(*args, **kwargs)
    return wrapped

def safe_next(target):
    if target and target.startswith('/') and not target.startswith('//'):
        return target
    return None