import ast
import os
import re
import subprocess
import threading
import time
import unicodedata
from hashlib import md5

import config

_RGB_TUPLE_RE = re.compile(r"\([0-9]{1,3}, [0-9]{1,3}, [0-9]{1,3}\)")

def _cleanup(path):
    try:
        os.remove(path)
    except OSError:
        pass

def _call_policy_error(tree):
    hooks = []

    def is_sys_attr(t):
        return (isinstance(t, ast.Attribute)
                and isinstance(t.value, ast.Name) and t.value.id == 'sys')

    def flat_targets(t):
        if isinstance(t, ast.Tuple):
            for e in t.elts:
                yield from flat_targets(e)
        else:
            yield t

    for node in ast.walk(tree):
        if isinstance(node, ast.Assign):
            for raw in node.targets:
                for t in flat_targets(raw):
                    if is_sys_attr(t):
                        if t.attr != 'breakpointhook':
                            return 'assignment into sys.<attr>'
                        if isinstance(node.value, ast.Lambda):
                            hooks.append(node.value)
        elif isinstance(node, ast.AnnAssign) and is_sys_attr(node.target):
            if node.target.attr != 'breakpointhook':
                return 'assignment into sys.<attr>'
            if isinstance(node.value, ast.Lambda):
                hooks.append(node.value)

    inside_hook = set()
    for h in hooks:
        for n in ast.walk(h):
            inside_hook.add(id(n))

    for node in ast.walk(tree):
        if isinstance(node, ast.Call) and id(node) not in inside_hook:
            if not (isinstance(node.func, ast.Name)
                    and node.func.id in config.ALLOWED_STATEMENT_CALLS):
                return 'call outside the breakpoint hook'
        if (isinstance(node, ast.Name)
                and isinstance(node.ctx, (ast.Store, ast.Del))
                and node.id in config.ALLOWED_STATEMENT_CALLS):
            return 'breakpoint rebinding'
    return None

_EXTRA_LINE_SEPS = "\x0b\x0c\x1c\x1d\x1e\x85\u2028\u2029"

def _fold_line_seps(code):
    code = code.replace("\r\n", "\n").replace("\r", "\n")
    for ch in _EXTRA_LINE_SEPS:
        code = code.replace(ch, "\n")
    return code

def xec(code):
    code = _fold_line_seps(unicodedata.normalize('NFKC', code)).strip()
    code_lower = code.lower()

    for word in config.BLACKLIST:
        if word in code_lower:
            return None

    if '__' in code:
        return None

    if "'" in code or '"' in code:
        return None

    try:
        tree = ast.parse(code)
    except SyntaxError:
        return None
    for node in ast.walk(tree):
        if isinstance(node, (ast.Import, ast.ImportFrom)):
            return None
    if _call_policy_error(tree):
        return None

    indented = "\n".join(["    " + line for line in code.splitlines()])

    ts = str(int(time.time()))
    file = f"{config.UPLOADS_DIR}/code_{md5(ts.encode()).hexdigest()}.py"
    with open(file, 'w') as f:
        f.write("def main():\n")
        f.write(indented)
        f.write(config.RUN_WRAPPER)

    os.system(f"chmod 755 {file}")

    try:
        res = subprocess.run(["sudo", "-u", "user", "python3", file], capture_output=True, text=True, check=True, timeout=0.1)
        output = res.stdout
    except Exception:
        output = None

    with open(file, 'a') as f:
        f.write("\n# === OUTPUT ===\n")
        f.write(output if output is not None else "# (no output / timed out)")

    threading.Timer(config.FILE_TTL, _cleanup, args=(file,)).start()

    return output

def rgb_from_output(output):
    if output is None:
        return None
    last = "".join(output.strip().split("\n")[-1])
    if _RGB_TUPLE_RE.fullmatch(last):
        return "rgb" + last
    return None