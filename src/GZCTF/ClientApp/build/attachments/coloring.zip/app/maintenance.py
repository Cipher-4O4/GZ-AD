#!/usr/bin/env python3
from __future__ import annotations

import os
import sqlite3
import sys
import time
from contextlib import closing

import accounts
import config
import palette_io

_TABLES = ("users", "profiles", "shares", "community")

def _log(message):
    print(f"maintenance: {message}", file=sys.stderr, flush=True)

def _delete(conn, sql, params=()):
    try:
        return conn.execute(sql, params).rowcount
    except sqlite3.OperationalError:
        return 0

def reset_database(ttl):
    cutoff = int(time.time()) - ttl
    counts = {name: 0 for name in _TABLES}
    try:
        conn = accounts.get_db()
    except sqlite3.Error:
        return counts
    with closing(conn):
        counts["users"] = _delete(
            conn, "DELETE FROM users WHERE created_at < ?", (cutoff,))
        counts["profiles"] = _delete(
            conn, "DELETE FROM profiles WHERE user_id NOT IN (SELECT id FROM users)")
        counts["shares"] = _delete(
            conn, "DELETE FROM shares WHERE created_at < ?", (cutoff,))
        counts["community"] = _delete(
            conn, "DELETE FROM community WHERE created_at < ?", (cutoff,))
        try:
            conn.commit()
        except sqlite3.Error:
            pass
    return counts

def prune_exports(ttl):
    cutoff = time.time() - ttl
    root = os.path.realpath(palette_io.EXPORT_DIR)
    try:
        names = os.listdir(root)
    except OSError:
        return 0
    removed = 0
    for name in names:
        path = os.path.join(root, name)
        try:
            if os.path.islink(path) or not os.path.isfile(path):
                continue
            if os.path.realpath(path) != path:
                continue
            if os.path.getmtime(path) >= cutoff:
                continue
            os.remove(path)
            removed += 1
        except OSError:
            continue
    return removed

def sweep():
    counts = reset_database(config.ACCOUNT_TTL)
    files = prune_exports(config.EXPORT_TTL)
    _log(f"reset db {counts} (ttl={config.ACCOUNT_TTL}s), "
         f"pruned {files} palette file(s) (ttl={config.EXPORT_TTL}s)")

def main():
    _log(f"starting: interval={config.MAINTENANCE_INTERVAL}s, "
         f"account_ttl={config.ACCOUNT_TTL}s, export_ttl={config.EXPORT_TTL}s, "
         f"db={config.DB_PATH}, exports={palette_io.EXPORT_DIR}")
    while True:
        try:
            sweep()
        except Exception as exc:
            _log(f"sweep failed: {exc!r}")
        time.sleep(config.MAINTENANCE_INTERVAL)

if __name__ == "__main__":
    main()