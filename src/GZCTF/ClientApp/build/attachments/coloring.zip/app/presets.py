import config

class Styles:
    def __init__(self):
        self.radius = "16px"
        self.shadow = "0 4px 32px rgba(120,80,60,0.08)"
        self.font = "'Segoe UI', system-ui, -apple-system, sans-serif"

    def to_css(self):
        return (":root {\n"
                f"    --radius: {self.radius};\n"
                f"    --shadow: {self.shadow};\n"
                f"    --font: {self.font};\n"
                "}")

class Theme:
    def __init__(self, bg, fg, accent, badge, title, dark=False):
        self.bg = bg
        self.fg = fg
        self.accent = accent
        self.badge = badge
        self.title = title
        self.dark = dark
        self.styles = Styles()

    def to_css(self):
        return (":root {\n"
                f"    --bg: {self.bg};\n"
                f"    --text: {self.fg};\n"
                f"    --accent: {self.accent};\n"
                "}\n" + self.styles.to_css())

PRESETS = {
    "warm": Theme("#fdf6f0", "#3d3055", "#ff6b6b", "🎨", "Show your color"),
    "mono": Theme("#f4f4f5", "#27272a", "#52525b", "🖤", "Show your color", dark=True),
}

def active(name):
    return PRESETS.get(name, PRESETS["warm"])

STYLE_FIELDS = frozenset({"radius", "shadow", "font"})

def patch_ok(patch, depth=0):
    if not isinstance(patch, dict) or not patch:
        return False
    if len(patch) > config.MAX_PATCH_KEYS or depth > 1:
        return False
    for key, value in patch.items():
        if depth == 0 and key == "styles":
            if not isinstance(value, dict) or not patch_ok(value, depth + 1):
                return False
            continue
        if depth == 0 and key == "dark":
            if not isinstance(value, bool):
                return False
            continue
        if key not in (config.PATCH_FIELDS if depth == 0 else STYLE_FIELDS):
            return False
        if not isinstance(value, str) or len(value) > config.MAX_OPTION_LEN:
            return False
    return True

def merge(target, patch):
    for key, value in patch.items():
        current = target.get(key) if isinstance(target, dict) else getattr(target, key, None)
        if isinstance(value, dict):
            if isinstance(current, Styles):
                merge(current, value)
            continue
        if isinstance(target, dict):
            target[key] = value
        elif hasattr(target, key):
            setattr(target, key, value)