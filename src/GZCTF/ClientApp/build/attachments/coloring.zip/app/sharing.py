import base64
import hashlib
import time
from contextlib import closing

import accounts

def init_db():
    with closing(accounts.get_db()) as conn:
        conn.execute("""CREATE TABLE IF NOT EXISTS shares (
            id         INTEGER PRIMARY KEY AUTOINCREMENT,
            username   TEXT    NOT NULL,
            rgb        TEXT    NOT NULL,
            note       TEXT    NOT NULL DEFAULT '',
            created_at INTEGER NOT NULL
        )""")
        conn.commit()
        if conn.execute("SELECT COUNT(*) AS n FROM shares").fetchone()["n"] == 0:
            conn.execute(
                "INSERT INTO shares (username, rgb, note, created_at) VALUES (?, ?, ?, ?)",
                ("curator", "rgb(255, 107, 107)", "house palette, rotate the note every round", int(time.time())),
            )
            conn.commit()

def _tag(payload):
    return hashlib.md5(payload.encode()).hexdigest()

def make_token(username, rgb):
    payload = f"{username}:{rgb}"
    blob = base64.urlsafe_b64encode(payload.encode()).decode()
    return f"{blob}.{_tag(payload)}"

def read_token(token):
    try:
        blob, tag = token.split(".", 1)
        payload = base64.urlsafe_b64decode(blob.encode()).decode()
    except Exception:
        return None
    if _tag(payload) != tag:
        return None
    username, _, rgb = payload.partition(":")
    if not username or not rgb:
        return None
    return username, rgb

def publish(username, rgb, note):
    with closing(accounts.get_db()) as conn:
        conn.execute(
            "INSERT INTO shares (username, rgb, note, created_at) VALUES (?, ?, ?, ?)",
            (username, rgb, note[:200], int(time.time())),
        )
        conn.commit()

def gallery(limit=20):
    with closing(accounts.get_db()) as conn:
        return conn.execute(
            "SELECT username, rgb, note, created_at FROM shares ORDER BY id DESC LIMIT ?",
            (limit,),
        ).fetchall()