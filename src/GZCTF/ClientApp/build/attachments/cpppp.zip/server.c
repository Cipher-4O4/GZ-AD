#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <signal.h>

int main() {
    signal(SIGCHLD, SIG_IGN);
    int s = socket(AF_INET, SOCK_STREAM, 0);
    int opt = 1;
    setsockopt(s, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt));
    struct sockaddr_in addr = { .sin_family = AF_INET, .sin_port = htons(7070), .sin_addr.s_addr = INADDR_ANY };
    if (bind(s, (struct sockaddr*)&addr, sizeof(addr)) < 0) {
        perror("bind");
        return 1;
    }
    listen(s, 100);
    printf("[(C)PPPP! Server] Listening on 0.0.0.0:7070...\n");
    fflush(stdout);
    while (1) {
        int c = accept(s, NULL, NULL);
        if (c < 0) continue;
        if (fork() == 0) {
            close(s);
            dup2(c, 0); dup2(c, 1); dup2(c, 2);
            close(c);
            execl("/app/chall", "/app/chall", NULL);
            exit(0);
        }
        close(c);
    }
    return 0;
}
